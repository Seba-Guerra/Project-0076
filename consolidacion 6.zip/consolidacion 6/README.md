# proyecto_vehiculos_django

Clave admin django

User: admin
password: admin

Usuario General

User: Andre
Password: SGG010203
